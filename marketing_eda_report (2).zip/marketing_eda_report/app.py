import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="Marketing Campaign EDA", page_icon="📈", layout="wide")
st.title("📈 Marketing Campaign EDA")
st.caption("Task 04 · Exploratory data analysis · Demonstration dataset — use actual campaign data for final recommendations.")
df = pd.read_csv("marketing_campaigns.csv")
df["CTR (%)"] = df.Clicks / df.Impressions * 100
df["Lead rate (%)"] = df.Leads / df.Clicks * 100
df["Conversion rate (%)"] = df.Conversions / df.Clicks * 100
df["Cost per lead"] = df.Spend / df.Leads
df["Cost per conversion"] = df.Spend / df.Conversions
df["ROAS"] = df.Revenue / df.Spend
df["Lead-to-customer (%)"] = df.Conversions / df.Leads * 100

with st.sidebar:
    st.header("Analysis filters")
    channels = st.multiselect("Channels", sorted(df.Channel.unique()), default=sorted(df.Channel.unique()))
    min_spend, max_spend = int(df.Spend.min()), int(df.Spend.max())
    spend_range = st.slider("Campaign spend range", min_spend, max_spend, (min_spend,max_spend), step=500)
f = df[df.Channel.isin(channels) & df.Spend.between(*spend_range)]
if f.empty:
    st.warning("No campaigns match the selected filters.")
    st.stop()
spend, revenue, conv, leads = f.Spend.sum(), f.Revenue.sum(), f.Conversions.sum(), f.Leads.sum()
c1,c2,c3,c4 = st.columns(4)
c1.metric("Total spend", f"${spend:,.0f}")
c2.metric("Attributed revenue", f"${revenue:,.0f}")
c3.metric("ROAS", f"{revenue/spend:.2f}x" if spend else "—")
c4.metric("Conversions", f"{conv:,}")
st.caption(f"Aggregate lead-to-customer rate: {conv/leads*100:.1f}% · Cost per conversion: ${spend/conv:,.2f}" if conv else "No conversions in this filter.")

left,right = st.columns(2)
with left:
    st.subheader("Spend vs. attributed revenue")
    st.plotly_chart(px.bar(f, x="Campaign", y=["Spend","Revenue"], barmode="group", title="Campaign-level investment and return"), use_container_width=True)
with right:
    st.subheader("Return on ad spend (ROAS)")
    roas = f.sort_values("ROAS", ascending=False)
    st.plotly_chart(px.bar(roas, x="Campaign", y="ROAS", color="Channel", title="Higher is better; revenue attribution assumed"), use_container_width=True)
left,right = st.columns(2)
with left:
    st.subheader("Marketing funnel")
    funnel = pd.DataFrame({"Stage":["Impressions","Clicks","Leads","Conversions"],"Count":[f.Impressions.sum(),f.Clicks.sum(),f.Leads.sum(),f.Conversions.sum()]})
    st.plotly_chart(px.funnel(funnel, x="Count", y="Stage"), use_container_width=True)
with right:
    st.subheader("Channel efficiency")
    ch = f.groupby("Channel", as_index=False).agg(Spend=("Spend","sum"),Revenue=("Revenue","sum"),Conversions=("Conversions","sum"),Leads=("Leads","sum"))
    ch["ROAS"] = ch.Revenue/ch.Spend
    ch["Cost per conversion"] = ch.Spend/ch.Conversions
    st.plotly_chart(px.scatter(ch, x="Spend", y="ROAS", size="Conversions", color="Channel", hover_name="Channel", title="Bubble size = conversions"), use_container_width=True)

st.subheader("Campaign performance table")
cols = ["Campaign","Channel","Spend","Revenue","ROAS","CTR (%)","Lead rate (%)","Conversion rate (%)","Cost per lead","Cost per conversion","Leads","Conversions"]
st.dataframe(f[cols].sort_values("ROAS", ascending=False).style.format({"ROAS":"{:.2f}x","CTR (%)":"{:.2f}%","Lead rate (%)":"{:.2f}%","Conversion rate (%)":"{:.2f}%","Cost per lead":"${:,.2f}","Cost per conversion":"${:,.2f}"}), use_container_width=True, hide_index=True)

st.subheader("Suggested interpretation")
rank = f.groupby("Channel", as_index=False).agg(Spend=("Spend","sum"),Revenue=("Revenue","sum"),Conversions=("Conversions","sum"))
rank["ROAS"] = rank.Revenue/rank.Spend
rank["Cost per conversion"] = rank.Spend/rank.Conversions
if len(rank):
    best = rank.sort_values("ROAS", ascending=False).iloc[0]
    weakest = rank.sort_values("ROAS").iloc[0]
    st.write(f"- Highest aggregate ROAS among selected channels: **{best['Channel']}** ({best['ROAS']:.2f}x). Validate volume and incrementality before increasing budget.")
    st.write(f"- Lowest aggregate ROAS among selected channels: **{weakest['Channel']}** ({weakest['ROAS']:.2f}x). Audit targeting, creative, landing pages and attribution before cutting spend.")
st.warning("ROAS is attributed revenue divided by spend, not profit. Before shifting budget, check margin, attribution windows, sample size, customer lifetime value and campaign objectives.")
