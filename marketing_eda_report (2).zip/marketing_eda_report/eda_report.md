# Marketing Campaign EDA — Business Insights Report

## Executive summary
This report demonstrates how to inspect campaign performance and allocate marketing budget using a small **synthetic** dataset. The interactive app provides channel filters and campaign-level metrics. Results should not be represented as real company findings.

## Questions
1. Which campaigns generate the strongest attributed revenue relative to spend?
2. At what stage does the funnel narrow most sharply?
3. Which channels should be investigated for additional budget, and which need optimization?

## Metrics
- **CTR:** clicks / impressions
- **Lead rate:** leads / clicks
- **Conversion rate:** conversions / clicks
- **Cost per lead:** spend / leads
- **Cost per conversion:** spend / conversions
- **ROAS:** attributed revenue / spend

## Findings to validate
- Compare campaigns on both ROAS and conversion volume; a high ratio on low volume may not scale.
- Inspect the funnel from impressions to clicks to leads to conversions. A large drop can reflect audience mismatch, creative quality, form friction, sales follow-up or attribution differences.
- Email retargeting and branded search can appear efficient because they often reach audiences already closer to purchase. Do not assume their results are fully incremental.
- Display/video awareness may have lower direct-response ROAS while contributing to later conversions. Evaluate with a suitable attribution or lift study.

## Budget recommendations
1. **Test before reallocating heavily.** Shift a small, controlled portion of budget toward efficient campaigns and compare against a holdout or matched period.
2. **Set guardrails.** Use target cost per acquisition, gross margin, payback period and minimum conversion volume—not ROAS alone.
3. **Optimize weak funnel stages.** Test landing pages, creative, audience exclusions and lead follow-up.
4. **Protect measurement quality.** Standardize attribution windows, deduplicate conversions and include refunds/margins where available.
5. **Reassess regularly.** Review weekly, but avoid reacting to tiny samples or seasonality.

## Caveats
The dataset is fictional and small. Revenue attribution is assumed, not verified. ROAS is not profit, correlation is not causation, and budget allocation needs margin, customer lifetime value, incrementality and statistical confidence.
