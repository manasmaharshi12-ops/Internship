# Marketing Campaign EDA

**Task 04 — Business Insights Report (EDA)**

Explore campaign performance using funnel counts, click-through rate, lead rate, conversion rate, cost per lead, cost per conversion and return on ad spend (ROAS).

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Files
- `app.py` — interactive EDA dashboard
- `marketing_campaigns.csv` — synthetic demo data
- `eda_report.md` — written findings and recommendations
- `requirements.txt` — dependencies

## Definitions
- CTR = clicks / impressions
- Lead rate = leads / clicks
- Conversion rate = conversions / clicks
- Cost per lead = spend / leads
- Cost per conversion = spend / conversions
- ROAS = attributed revenue / spend

## Important limitation
The dataset is fictional. ROAS does not equal profit and does not prove incrementality. Use real campaign data and validate margins, attribution and statistical reliability before recommending budget changes.
