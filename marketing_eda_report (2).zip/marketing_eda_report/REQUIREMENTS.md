# Requirements — Task 04: Marketing Campaign EDA

## 1. Project objective
Perform exploratory data analysis on marketing campaign data, explain why campaign performance differs, and recommend where to test budget changes based on return and funnel efficiency.

## 2. Required tools / platform options

### Option A — Python dashboard (already included)
- Python 3.10 or newer
- Streamlit
- pandas
- Plotly
- A browser
- Install dependencies: `pip install -r requirements.txt`
- Run: `streamlit run app.py`

### Option B — Tableau
- Tableau Public (free, suitable for a public portfolio) or Tableau Desktop
- Import `marketing_campaigns.csv`
- Create calculated fields:
  - `CTR`: `SUM([Clicks]) / SUM([Impressions])`
  - `Lead Rate`: `SUM([Leads]) / SUM([Clicks])`
  - `Conversion Rate`: `SUM([Conversions]) / SUM([Clicks])`
  - `Cost per Lead`: `SUM([Spend]) / SUM([Leads])`
  - `Cost per Conversion`: `SUM([Spend]) / SUM([Conversions])`
  - `ROAS`: `SUM([Revenue]) / SUM([Spend])`
- Create worksheets:
  1. KPI cards for spend, attributed revenue, ROAS and conversions
  2. Spend vs. revenue by campaign
  3. ROAS by campaign or channel
  4. Funnel: impressions → clicks → leads → conversions
  5. Scatter plot: spend vs. ROAS, with conversion volume represented by size
  6. Campaign performance table
- Add filters for Channel and Campaign; optionally add date if the real dataset has a date field.
- Use aggregate formulas (`SUM` ratios) rather than averaging campaign-level percentages when calculating overall performance.

### Option C — Microsoft Power BI
- Power BI Desktop (Windows)
- Load `marketing_campaigns.csv` via Get Data → Text/CSV
- Suggested DAX measures:
  ```DAX
  Total Spend = SUM(Campaigns[Spend])
  Attributed Revenue = SUM(Campaigns[Revenue])
  Total Conversions = SUM(Campaigns[Conversions])
  Total Leads = SUM(Campaigns[Leads])
  ROAS = DIVIDE([Attributed Revenue], [Total Spend], 0)
  CTR = DIVIDE(SUM(Campaigns[Clicks]), SUM(Campaigns[Impressions]), 0)
  Lead Rate = DIVIDE([Total Leads], SUM(Campaigns[Clicks]), 0)
  Conversion Rate = DIVIDE([Total Conversions], SUM(Campaigns[Clicks]), 0)
  Cost per Lead = DIVIDE([Total Spend], [Total Leads], 0)
  Cost per Conversion = DIVIDE([Total Spend], [Total Conversions], 0)
  ```
- Create KPI cards, campaign spend/revenue comparison, ROAS ranking, funnel chart, scatter chart, and detailed campaign table.
- Add slicers for Channel and Campaign.
- Format CTR and conversion rates as percentages; ROAS as a multiple (e.g., 2.4x) or decimal; costs as currency.
- Publish to Power BI Service only if your account/license and organizational settings allow it.

## 3. Dataset fields
`Campaign`, `Channel`, `Spend`, `Impressions`, `Clicks`, `Leads`, `Conversions`, `Revenue`.

## 4. Required deliverables
- EDA dashboard with interactive channel/campaign filters
- Campaign funnel visualization
- KPI cards and campaign-level performance table
- A one-page summary explaining findings and budget recommendations
- Source file (`app.py`, `.twb/.twbx`, or `.pbix`), dataset and README

## 5. Quality and interpretation checks
- Validate numeric types, missing values, duplicates and zero denominators.
- Verify funnel counts are logically consistent and define what counts as a conversion.
- ROAS = attributed revenue / spend; it is not profit or proof that advertising caused the revenue.
- Consider margin, attribution windows, seasonality, customer lifetime value and incrementality before recommending budget shifts.
- The included CSV is synthetic demonstration data. Replace it with official course data for a final submission.
