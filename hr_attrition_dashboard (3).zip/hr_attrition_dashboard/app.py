import streamlit as st
import pandas as pd
import plotly.express as px

st.set_page_config(page_title="HR Attrition Insights", page_icon="📊", layout="wide")
st.title("📊 HR Attrition Insights")
st.caption("Task 03 · Interactive visualization · Demonstration dataset — replace with real HR data before drawing business conclusions.")

df = pd.read_csv("hr_employee_attrition.csv")
with st.sidebar:
    st.header("Dashboard filters")
    departments = st.multiselect("Department", sorted(df.Department.unique()), default=sorted(df.Department.unique()))
    ages = st.multiselect("Age group", sorted(df.AgeGroup.unique()), default=sorted(df.AgeGroup.unique()))
    regions = st.multiselect("Region", sorted(df.Region.unique()), default=sorted(df.Region.unique()))
    roles = st.multiselect("Job role", sorted(df.JobRole.unique()), default=sorted(df.JobRole.unique()))
filtered = df[df.Department.isin(departments) & df.AgeGroup.isin(ages) & df.Region.isin(regions) & df.JobRole.isin(roles)]
if filtered.empty:
    st.warning("No employees match these filters. Select more values.")
    st.stop()

total = len(filtered)
leavers = (filtered.Attrition == "Yes").sum()
rate = leavers / total * 100
c1,c2,c3,c4 = st.columns(4)
c1.metric("Employees in view", f"{total:,}")
c2.metric("Employees leaving", f"{leavers:,}")
c3.metric("Attrition rate", f"{rate:.1f}%")
c4.metric("Avg. years at company", f"{filtered.YearsAtCompany.mean():.1f}")

left,right = st.columns(2)
with left:
    dep = filtered.groupby("Department", as_index=False).agg(Employees=("EmployeeID","count"), Leavers=("Attrition",lambda s:(s=="Yes").sum()))
    dep["Attrition rate (%)"] = dep.Leavers / dep.Employees * 100
    st.subheader("Attrition by department")
    st.plotly_chart(px.bar(dep, x="Department", y="Attrition rate (%)", color="Department", text_auto=".1f"), use_container_width=True)
with right:
    age = filtered.groupby("AgeGroup", as_index=False).agg(Employees=("EmployeeID","count"), Leavers=("Attrition",lambda s:(s=="Yes").sum()))
    age["Attrition rate (%)"] = age.Leavers / age.Employees * 100
    st.subheader("Attrition by age group")
    st.plotly_chart(px.bar(age, x="AgeGroup", y="Attrition rate (%)", color="AgeGroup", text_auto=".1f"), use_container_width=True)

left,right = st.columns(2)
with left:
    st.subheader("Overtime and attrition")
    ot = filtered.groupby("OverTime", as_index=False).agg(Employees=("EmployeeID","count"), Leavers=("Attrition",lambda s:(s=="Yes").sum()))
    ot["Attrition rate (%)"] = ot.Leavers / ot.Employees * 100
    st.plotly_chart(px.bar(ot, x="OverTime", y="Attrition rate (%)", color="OverTime", text_auto=".1f"), use_container_width=True)
with right:
    st.subheader("Job satisfaction")
    sat = filtered.groupby(["JobSatisfaction","Attrition"], as_index=False).size()
    st.plotly_chart(px.bar(sat, x="JobSatisfaction", y="size", color="Attrition", barmode="group", labels={"size":"Employees","JobSatisfaction":"Satisfaction (1–4)"}), use_container_width=True)

st.subheader("Filtered employee records")
st.dataframe(filtered, use_container_width=True, hide_index=True)
st.info("Interpretation: this small synthetic dataset is only for demonstrating filtering and visualization. Patterns are illustrative, not statistically reliable. Investigate exit interviews, compensation, workload, manager quality and career progression using real data.")
