# Requirements — Task 03: Interactive HR Attrition Visualization

## 1. Project objective
Build an interactive report that helps users explore employee attrition and investigate which employee groups or workplace factors are associated with leaving.

## 2. Required tools / platform options

### Option A — Python dashboard (already included)
- Python 3.10 or newer
- Streamlit
- pandas
- Plotly
- A browser
- Install dependencies: `pip install -r requirements.txt`
- Run: `streamlit run app.py`

### Option B — Tableau
- Tableau Public (free, suitable for a public portfolio) or Tableau Desktop
- Import `hr_employee_attrition.csv`
- Create calculated fields:
  - `Attrition Flag`: `IF [Attrition] = "Yes" THEN 1 ELSE 0 END`
  - `Attrition Rate`: `SUM([Attrition Flag]) / COUNT([EmployeeID])`
- Create worksheets:
  1. KPI: employee count
  2. KPI: leavers
  3. KPI: attrition rate
  4. Attrition rate by department
  5. Attrition rate by age group
  6. Attrition by overtime
  7. Job satisfaction vs. attrition
- Add dashboard filters: Department, AgeGroup, Region, JobRole
- Ensure the attrition rate is formatted as a percentage and filters apply to all relevant worksheets.

### Option C — Microsoft Power BI
- Power BI Desktop (Windows)
- Load `hr_employee_attrition.csv` using Get Data → Text/CSV
- Suggested DAX measures:
  ```DAX
  Employee Count = DISTINCTCOUNT(HR[EmployeeID])
  Leavers = CALCULATE([Employee Count], HR[Attrition] = "Yes")
  Attrition Rate = DIVIDE([Leavers], [Employee Count], 0)
  Average Tenure = AVERAGE(HR[YearsAtCompany])
  ```
- Create visuals: KPI cards, clustered/bar charts by Department and AgeGroup, overtime comparison, job satisfaction chart, and an employee detail table.
- Add slicers: Department, AgeGroup, Region, JobRole.
- Format `Attrition Rate` as Percentage; check that slicers filter the full report.
- Publish to Power BI Service only if your account/license and organizational settings allow it.

## 3. Dataset fields
`EmployeeID`, `Age`, `AgeGroup`, `Department`, `Region`, `JobRole`, `YearsAtCompany`, `MonthlyIncome`, `OverTime`, `JobSatisfaction`, `Attrition`.

## 4. Required deliverables
- Interactive dashboard with working filters
- At least four meaningful charts
- KPI cards for employee count, leavers, attrition rate and average tenure
- Brief written findings and recommendations
- Source file (`app.py`, `.twb/.twbx`, or `.pbix`) and dataset
- README explaining how to open or run the project

## 5. Quality and interpretation checks
- Validate missing values and duplicate employee IDs.
- Confirm attrition rate = leavers / employees in the selected population.
- Use the same denominator consistently across visuals.
- Label units and percentages clearly.
- Avoid claiming causation from a small observational dataset.
- The included CSV is synthetic demonstration data. Replace it with official course data for a final submission.
