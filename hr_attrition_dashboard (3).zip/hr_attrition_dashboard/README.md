# HR Attrition Insights Dashboard

**Task 03 — Interactive Visualization**

A Streamlit dashboard that allows users to filter employee records by department, age group, region and job role. It visualizes attrition rates, overtime, and job satisfaction.

## Run locally
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

## Files
- `app.py` — interactive dashboard
- `hr_employee_attrition.csv` — small synthetic demo dataset
- `requirements.txt` — Python dependencies

## GitHub deployment
Push this folder to a GitHub repository. On Streamlit Community Cloud, select the repository and set the main file path to `app.py`.

## Data note
The included records are synthetic and deliberately small. Replace them with your course-provided HR dataset before making real-world claims. Attrition rate = employees marked `Yes` / employees in the filtered view.
